module.exports = {
    "cookieSecret": "kghkasfcgnasuyg6526as",
    "mongo": {
        "connectionString": "mongodb://localhost:27017/final_advanced_web"
    }
}